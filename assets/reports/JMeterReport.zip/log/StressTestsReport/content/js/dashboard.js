/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "DELETE User"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create CoverPhotos"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Authors"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author By Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET User"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Users"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update CoverPhotos"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Users"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Author"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Activity"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Activities"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Books"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Authors"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Book"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Books"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Books"], "isController": false}, {"data": [1.0, 500, 1500, "GET Cover By Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET Activity"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Users"], "isController": false}, {"data": [1.0, 500, 1500, "GET All CoverPhotos"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Authors"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1620, 0, 0.0, 42.324691358024744, 33, 118, 37.0, 69.0, 77.0, 105.0, 277.4922918807811, 1776.5995351040597, 62.46687917523124], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DELETE User", 60, 0, 0.0, 36.81666666666666, 33, 44, 36.0, 39.9, 41.949999999999996, 44.0, 12.78772378516624, 2.6349704283887467, 2.523827125959079], "isController": false}, {"data": ["POST Create CoverPhotos", 60, 0, 0.0, 39.54999999999999, 34, 48, 39.5, 43.0, 45.949999999999996, 48.0, 12.78772378516624, 3.7501498561381075, 3.3630214993606136], "isController": false}, {"data": ["PUT Update Activity", 60, 0, 0.0, 37.26666666666666, 33, 48, 37.0, 40.0, 44.84999999999999, 48.0, 12.790449797484545, 4.236836495416756, 3.950800069281603], "isController": false}, {"data": ["DELETE CoverPhoto", 60, 0, 0.0, 36.650000000000006, 33, 42, 36.0, 39.0, 40.949999999999996, 42.0, 12.793176972281449, 2.6360940831556503, 2.5998634061833688], "isController": false}, {"data": ["GET Book", 60, 0, 0.0, 43.483333333333334, 38, 52, 44.0, 48.0, 49.0, 52.0, 12.78227524499361, 9.252170323817639, 2.2481325894759268], "isController": false}, {"data": ["GET All Authors", 60, 0, 0.0, 87.3833333333333, 66, 113, 78.0, 110.0, 112.94999999999999, 113.0, 12.676949080921192, 588.69325084513, 2.2283699556306784], "isController": false}, {"data": ["GET Author By Book", 60, 0, 0.0, 37.766666666666666, 34, 48, 37.0, 41.8, 42.0, 48.0, 12.776831345826235, 5.968136113181432, 2.2970846198892674], "isController": false}, {"data": ["GET User", 60, 0, 0.0, 36.66666666666667, 34, 41, 36.0, 39.0, 40.0, 41.0, 12.795905310300704, 3.8775091970569417, 2.2505298304542545], "isController": false}, {"data": ["GET Author", 60, 0, 0.0, 37.94999999999998, 34, 49, 38.0, 41.0, 43.89999999999999, 49.0, 12.779552715654951, 4.122154552715655, 2.2726138178913735], "isController": false}, {"data": ["POST Create Users", 60, 0, 0.0, 37.18333333333332, 33, 63, 36.5, 39.9, 40.949999999999996, 63.0, 12.793176972281449, 3.9141624466950957, 3.3769489605543708], "isController": false}, {"data": ["PUT Update CoverPhotos", 60, 0, 0.0, 39.183333333333344, 35, 60, 38.0, 42.9, 48.699999999999974, 60.0, 12.784998934583422, 3.7493507617728534, 3.376038781163435], "isController": false}, {"data": ["PUT Update Users", 60, 0, 0.0, 37.233333333333334, 33, 57, 37.0, 39.9, 40.949999999999996, 57.0, 12.784998934583422, 3.9116603185595573, 3.3885241316854895], "isController": false}, {"data": ["GET CoverPhoto", 60, 0, 0.0, 37.61666666666666, 34, 45, 37.0, 41.0, 43.0, 45.0, 12.793176972281449, 4.45262526652452, 2.3250099946695095], "isController": false}, {"data": ["DELETE Author", 60, 0, 0.0, 37.050000000000004, 33, 51, 36.5, 40.9, 42.0, 51.0, 12.784998934583422, 2.6344089601534204, 2.548260041551247], "isController": false}, {"data": ["POST Create Activity", 60, 0, 0.0, 37.03333333333334, 34, 49, 36.0, 40.0, 43.84999999999999, 49.0, 12.78227524499361, 4.234128674904133, 3.9345440988495954], "isController": false}, {"data": ["GET All Activities", 60, 0, 0.0, 72.46666666666668, 65, 118, 70.0, 76.0, 85.69999999999997, 118.0, 12.655557899177388, 38.39305724003375, 2.2616866167475216], "isController": false}, {"data": ["GET All Books", 60, 0, 0.0, 80.46666666666668, 71, 93, 80.0, 87.9, 90.89999999999999, 93.0, 12.658227848101266, 1205.4125049446202, 2.2003560126582276], "isController": false}, {"data": ["PUT Update Authors", 60, 0, 0.0, 36.96666666666667, 33, 46, 37.0, 39.9, 40.949999999999996, 46.0, 12.795905310300704, 4.014965211132438, 3.578854766474728], "isController": false}, {"data": ["DELETE Activity", 60, 0, 0.0, 36.550000000000004, 33, 43, 36.0, 39.9, 41.0, 43.0, 12.790449797484545, 2.6355321360051165, 2.586818508846728], "isController": false}, {"data": ["DELETE Book", 60, 0, 0.0, 36.15, 34, 40, 36.0, 38.0, 39.0, 40.0, 12.795905310300704, 2.636656269993602, 2.5254418586052463], "isController": false}, {"data": ["POST Create Books", 60, 0, 0.0, 37.61666666666666, 34, 62, 36.5, 42.699999999999996, 44.0, 62.0, 12.79863481228669, 4.918225389291809, 4.568262718643345], "isController": false}, {"data": ["PUT Update Books", 60, 0, 0.0, 37.18333333333335, 33, 59, 37.0, 39.9, 40.0, 59.0, 12.793176972281449, 4.916128065031983, 4.580057302771855], "isController": false}, {"data": ["GET Cover By Book", 60, 0, 0.0, 37.51666666666666, 33, 48, 37.0, 40.9, 42.949999999999996, 48.0, 12.795905310300704, 4.478566858605246, 2.288017834293026], "isController": false}, {"data": ["GET Activity", 60, 0, 0.0, 37.08333333333333, 33, 44, 36.0, 41.9, 43.0, 44.0, 12.784998934583422, 4.389641154378863, 2.311038381632218], "isController": false}, {"data": ["GET All Users", 60, 0, 0.0, 36.61666666666666, 33, 46, 36.0, 39.0, 41.0, 46.0, 12.78227524499361, 9.786429484448233, 2.2219189390711547], "isController": false}, {"data": ["GET All CoverPhotos", 60, 0, 0.0, 38.33333333333334, 34, 47, 38.0, 42.0, 44.84999999999999, 47.0, 12.779552715654951, 258.8233825878594, 2.296325878594249], "isController": false}, {"data": ["POST Create Authors", 60, 0, 0.0, 36.98333333333334, 33, 44, 37.0, 39.0, 40.89999999999999, 44.0, 12.78772378516624, 4.012398097826087, 3.562829683503836], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1620, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
