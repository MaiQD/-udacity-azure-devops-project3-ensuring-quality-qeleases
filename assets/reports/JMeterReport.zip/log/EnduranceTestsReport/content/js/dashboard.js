/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "DELETE User"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create CoverPhotos"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "GET Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Authors"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author By Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET User"], "isController": false}, {"data": [1.0, 500, 1500, "GET Author"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Users"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update CoverPhotos"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Users"], "isController": false}, {"data": [1.0, 500, 1500, "GET CoverPhoto"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Author"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Activity"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Activities"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Books"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Authors"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Activity"], "isController": false}, {"data": [1.0, 500, 1500, "DELETE Book"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Books"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Books"], "isController": false}, {"data": [1.0, 500, 1500, "GET Cover By Book"], "isController": false}, {"data": [1.0, 500, 1500, "GET Activity"], "isController": false}, {"data": [1.0, 500, 1500, "GET All Users"], "isController": false}, {"data": [1.0, 500, 1500, "GET All CoverPhotos"], "isController": false}, {"data": [1.0, 500, 1500, "POST Create Authors"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 62260, 0, 0.0, 43.66697719241853, 32, 348, 38.0, 69.0, 80.0, 108.0, 519.9295180672585, 3422.359974310421, 117.02892184929476], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DELETE User", 2292, 0, 0.0, 37.431064572425825, 32, 113, 37.0, 41.0, 44.0, 57.0, 19.40711763659918, 3.9989275598851832, 3.830250762588801], "isController": false}, {"data": ["POST Create CoverPhotos", 2308, 0, 0.0, 41.45450606585779, 34, 134, 40.0, 48.0, 54.0, 71.0, 19.466279815120945, 5.708694908446072, 5.1193837031054965], "isController": false}, {"data": ["PUT Update Activity", 2305, 0, 0.0, 38.658568329718015, 32, 118, 37.0, 44.0, 49.0, 66.0, 19.48535006001995, 6.45451395199672, 6.018753460657345], "isController": false}, {"data": ["DELETE CoverPhoto", 2294, 0, 0.0, 37.426329555361804, 32, 88, 37.0, 41.0, 44.0, 54.0, 19.416489627328666, 4.0008587025062, 3.9458672908537666], "isController": false}, {"data": ["GET Book", 2310, 0, 0.0, 46.24891774891779, 36, 163, 45.0, 53.0, 56.0, 72.0, 19.448045934432304, 14.513444658838337, 3.4205010476477122], "isController": false}, {"data": ["GET All Authors", 2312, 0, 0.0, 88.52249134948089, 65, 157, 80.0, 112.0, 115.0, 124.0, 19.34080642462774, 897.4833459903589, 3.3997511293290947], "isController": false}, {"data": ["GET Author By Book", 2310, 0, 0.0, 38.90000000000006, 33, 122, 38.0, 44.0, 48.0, 62.0, 19.448045934432304, 9.128308167337385, 3.4964699770790886], "isController": false}, {"data": ["GET User", 2310, 0, 0.0, 37.8450216450216, 32, 115, 37.0, 42.0, 46.0, 57.0, 19.448700894135083, 5.893488171338003, 3.420616241243875], "isController": false}, {"data": ["GET Author", 2310, 0, 0.0, 39.23549783549787, 33, 124, 38.0, 45.0, 49.0, 64.0, 19.44788220139924, 6.273081534298992, 3.4584563953855483], "isController": false}, {"data": ["POST Create Users", 2308, 0, 0.0, 38.40944540727901, 32, 95, 37.0, 43.0, 48.0, 64.0, 19.46989252754298, 5.956930745010207, 5.1393473673887735], "isController": false}, {"data": ["PUT Update CoverPhotos", 2304, 0, 0.0, 41.19270833333324, 34, 138, 39.0, 47.0, 52.0, 70.94999999999982, 19.47870784474523, 5.7123494341959535, 5.14358308040885], "isController": false}, {"data": ["PUT Update Users", 2303, 0, 0.0, 38.27051671732525, 32, 98, 37.0, 43.0, 47.0, 60.0, 19.4715704924963, 5.957456470619319, 5.160716880680617], "isController": false}, {"data": ["GET CoverPhoto", 2310, 0, 0.0, 38.340692640692566, 33, 97, 37.0, 43.0, 47.0, 57.88999999999987, 19.448537150073665, 6.769002578404546, 3.5345437144811616], "isController": false}, {"data": ["DELETE Author", 2298, 0, 0.0, 37.32898172323758, 32, 81, 37.0, 41.0, 44.0, 53.0, 19.444091889833736, 4.006546278080974, 3.87551990787748], "isController": false}, {"data": ["POST Create Activity", 2308, 0, 0.0, 38.690641247833526, 33, 134, 37.0, 44.0, 49.0, 66.90999999999985, 19.464638116281815, 6.447648198593283, 5.991445742742928], "isController": false}, {"data": ["GET All Activities", 2315, 0, 0.0, 72.67688984881215, 63, 157, 71.0, 78.0, 83.19999999999982, 124.84000000000015, 19.332425864531054, 58.62659920499052, 3.4549159503995925], "isController": false}, {"data": ["GET All Books", 2311, 0, 0.0, 84.73734314149692, 69, 348, 82.0, 93.0, 99.0, 126.52000000000044, 19.359811009374134, 1929.9941202218295, 3.3652796481138636], "isController": false}, {"data": ["PUT Update Authors", 2305, 0, 0.0, 38.504555314533526, 32, 126, 37.0, 43.0, 49.0, 66.94000000000005, 19.486338428242934, 6.1142068907031994, 5.450068767541932], "isController": false}, {"data": ["DELETE Activity", 2298, 0, 0.0, 37.40687554395128, 32, 77, 37.0, 41.0, 44.0, 55.00999999999976, 19.443762850398098, 4.006478477962889, 3.9324184740072936], "isController": false}, {"data": ["DELETE Book", 2289, 0, 0.0, 37.32983835736129, 32, 96, 37.0, 41.0, 44.0, 56.0, 19.389760444549857, 3.995351029101582, 3.8268275712186153], "isController": false}, {"data": ["POST Create Books", 2307, 0, 0.0, 38.539228435197195, 32, 119, 37.0, 43.0, 48.0, 67.92000000000007, 19.475257053132754, 7.483871195381486, 6.951344635334887], "isController": false}, {"data": ["PUT Update Books", 2302, 0, 0.0, 38.5304083405734, 32, 131, 37.0, 44.0, 48.0, 66.9699999999998, 19.464267595630265, 7.479668792488247, 6.968349955186525], "isController": false}, {"data": ["GET Cover By Book", 2310, 0, 0.0, 38.696969696969695, 32, 134, 37.0, 43.0, 48.0, 64.0, 19.44886464095375, 6.8071026243338135, 3.477624136483039], "isController": false}, {"data": ["GET Activity", 2310, 0, 0.0, 37.885281385281345, 32, 130, 37.0, 42.0, 46.44999999999982, 60.88999999999987, 19.447554743603774, 6.677097386682213, 3.5153734209385337], "isController": false}, {"data": ["GET All Users", 2311, 0, 0.0, 37.60017308524447, 32, 97, 37.0, 41.0, 45.0, 58.88000000000011, 19.365651317719024, 14.82682679012863, 3.366294857962878], "isController": false}, {"data": ["GET All CoverPhotos", 2312, 0, 0.0, 40.11548442906578, 33, 105, 39.0, 46.0, 51.0, 67.86999999999989, 19.35375858027792, 391.9703117152185, 3.4776284948936884], "isController": false}, {"data": ["POST Create Authors", 2308, 0, 0.0, 38.61698440207974, 32, 122, 37.0, 44.0, 49.0, 63.909999999999854, 19.465787276392252, 6.107751181821249, 5.423407097885584], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 62260, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
